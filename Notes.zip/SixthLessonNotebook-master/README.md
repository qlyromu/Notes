# SixthLessonNotebook
<p align="left">
<img src="https://user-images.githubusercontent.com/108148690/226387180-b6cf190b-10e3-4691-9112-b6cb0742fd55.jpeg"/>
</p>
<p align="left">
<img src="https://user-images.githubusercontent.com/108148690/226387368-ef1e5aa3-b1cc-4f42-9948-2f29bee8a840.jpeg"/>
</p>
